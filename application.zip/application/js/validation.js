$().ready(function() {

$("#signupForm").validate({
			rules: {
				
				vchUserName: {
					required: true,
					minlength: 2,
					lettersonly:true
					
				},
				
				
				vchEmail: {
					required: true,
					email: true
				},
				vchDateofBirth :
				{
				  required: true,
				},
				vchFavoriteColor :
				{
				  required: true,
				  lettersonly:true,
				},
				
			},
			messages: {
				
				vchUserName: {
					required: "Please enter a username",
					minlength: "Your username must consist of at least 2 characters"
				},
				
				vchEmail: "Please enter a valid email address",
			     	vchDateofBirth:"Please enter a date of birth",
				vchFavoriteColor: 
				{
				required:"Please enter a favorite color"
				}		    
				
				
			}
		});

});

$.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Letters only please");






