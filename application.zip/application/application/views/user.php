<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8" />
        <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">  -->
        <title>Login and Registration Form with HTML5 and CSS3</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
        <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="../favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/demo.css" />
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/style2.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/animate-custom.css" />
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>js/validation.js"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <style>
#vchUserName-error
{
color: #ca0000 !important;
}
#vchEmail-error
{
color: #ca0000 !important;
}
#datepicker-error
{
color: #ca0000 !important;
}
#vchFavoriteColor-error
{
color: #ca0000 !important;
}
</style>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker(
{	    changeMonth: true,
            changeYear: true,
	    yearRange: "-100:+0",
            showButtonPanel: true
});
  } );
  </script>
    </head>
    <body>
        <div class="container">
            <!-- Codrops top bar -->
            <div class="codrops-top">
                
                <span class="right">
                   
                </span>
                <div class="clr"></div>
            </div><!--/ Codrops top bar -->
            <header>
                <h1>Registration Form </h1>
				
            </header>
            <section>				
                <div id="container_demo" >
                    <!-- hidden anchor to stop jump http://www.css3create.com/Astuce-Empecher-le-scroll-avec-l-utilisation-de-target#wrap4  -->
                   
                    <div id="wrapper">
                        <div id="login" class="animate form">
			
		
                             <form  action="<?php echo base_url();?>index.php/user/add" autocomplete="on" id="signupForm" name="signupForm" method="post"> 
                                <h1> User Information </h1> 
				<?php if($this->session->flashdata('message')){ ?>
			<?php echo"<p style=color:green;>".$this->session->flashdata('message')."</p>";

 } ?>
				 <?php echo form_error('vchUserName'); ?>
 				<?php echo form_error('vchEmail'); ?>
                                <p> 
                                    <label for="usernamesignup" class="uname" data-icon="u">Name</label>
                                    <input id="vchUserName" name="vchUserName"  type="text" placeholder="User Name" />
                                </p>
                                <p> 
					
                                    <label for="emailsignup" class="youmail" data-icon="e" > Email</label>
                                    <input id="vchEmail" name="vchEmail"  type="email" placeholder="Email Address"/> 
				   
                                </p>
                                <p> 
                                    <label for="passwordsignup" class="youpasswd" data-icon="p">Date of Birth</label>
                                    <input id="datepicker" name="vchDateofBirth"  type="text" placeholder="Date of Birth"/>
                                </p>
                                <p> 
                                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Favorite Color </label>
                                    <input id="vchFavoriteColor" name="vchFavoriteColor" type="text" placeholder="Favorite Color"/>
                                </p>
                                <p class="signin button"> 
									<input type="submit" value="Submit"/> 
								</p>
                                
                            </form>
                        </div>

                        		
                    </div>
                </div>  
            </section>
        </div>
    </body>
</html>
