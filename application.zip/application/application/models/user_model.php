<?php
class User_model extends ci_model{



function addUserInfo($data)
{
  $this->load->database();
 return $this->db->insert('user_info',$data);
  



}

}
?>
