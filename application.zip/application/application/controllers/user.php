<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller {
	function __contruct()
    {
        parent::__construct();
        $this->load->model('user_model');
	$this->load->library('session');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
            $this->load->library('form_validation');
           $this->load->library('session'); 
		$this->load->view('user');
	}
	public function add()
	{
	 $this->load->model('user_model');
	 $this->load->library('session'); 
	  if($this->input->post())
	  {
 
		$this->load->helper(array('form', 'url'));

                $this->load->library('form_validation');

                $this->form_validation->set_rules('vchUserName', 'Username', 'required');
                $this->form_validation->set_rules('vchEmail', 'Email', 'required');
               
                  $this->form_validation->run();

                if ($this->form_validation->run() == FALSE)
                {
                	
                        $this->load->view('user');
                }
                else
 	        {
		  $Post_array=array('vchUsername'=>addslashes($this->input->post('vchUserName')),
					'vchEmail'=>$this->input->post('vchEmail'),
				        'vchDateOfBirth'=>$this->input->post('vchDateofBirth'),
					'vchFavoriteColor'=>$this->input->post('vchFavoriteColor'),
					'dt_Date'=>date('Y-m-d h:m:s')
					);
	
			if(!empty($this->user_model->addUserInfo($Post_array)))
			{
			 $this->session->set_flashdata('message', 'User info Added Successfully.');
			}
			else
			{
				$this->session->set_flashdata('message', 'Error in Data insertion,Please Try Again.');
			}
		
                      
                }
	

	  }
		redirect('user');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */
